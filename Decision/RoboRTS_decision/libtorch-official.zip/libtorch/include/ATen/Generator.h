#pragma once
#include <ATen/core/Generator.h>
