#pragma once
#include <ATen/core/Type.h>
